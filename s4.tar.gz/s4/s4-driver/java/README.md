S4 Client Driver
===============

Introduction
------------
This library provides client access to an S4 cluster

Requirements
------------

* Linux
* Java 1.6
* Maven

Build Instructions
------------------

1. Build and install using Maven

        mvn install

