package io.s4.comm.core;

public enum CommLayerState {
    INITIALIZED, BROKEN
}
